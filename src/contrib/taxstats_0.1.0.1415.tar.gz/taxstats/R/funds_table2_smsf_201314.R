#' SMSF funds time series data
#' 
#' @source \url{http://data.gov.au/dataset/25e81c18-2083-4abe-81b6-0f530053c63f/resource/68ac57dd-1660-4aa0-be5a-f0b9a51064a2/download/taxstats2014fund2smsfselecteditemsbyyear.xlsx}
#' 
#' @description This is a long form of the data relating to self-managed super funds on data.gov.au.
#' 
#' @format A data table with 1455 rows and 5 columns.
#' \describe{
#' \item{Superheading}{The group of the \code{Selected_items}. (Mostly equates to the boldface cells of the original Excel file.)}
#' \item{Selected_items}{The variable, often called Selected items in the sheet.}
#' \item{fy_year}{The financial year.}
#' \item{Count}{The number (of individuals etc) with nonzero values. (Corresponds to no. in original.)}
#' \item{Sum}{The total value (in dollars). (Corresponds to $ in original.)}
#' }
#' 
"funds_table2_smsf_201314"
